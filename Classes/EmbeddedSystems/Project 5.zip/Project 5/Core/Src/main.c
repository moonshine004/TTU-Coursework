/* Amna Malik 5/2/2026
 * I added audio control to my FreeRTOS CLI using the DAC and DMA.
 * I used a 64-point sine table to generate a continuous sine wave.
 * The CLI lets me change frequency, amplitude, run a frequency ramp,
 * and play a test song.
 * The ramp and playtest run as separate tasks, and I used semaphores
 * and a mutex to manage communication and UART access.
 */
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "usb_host.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */  /* USER CODE BEGIN StartDefaultTask */


/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

DAC_HandleTypeDef hdac;
DMA_HandleTypeDef hdma_dac2;

DMA2D_HandleTypeDef hdma2d;

LTDC_HandleTypeDef hltdc;

SPI_HandleTypeDef hspi5;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim7;

UART_HandleTypeDef huart1;

SDRAM_HandleTypeDef hsdram1;

/* Definitions for commandTask */
osThreadId_t commandTaskHandle;
const osThreadAttr_t commandTask_attributes = {
  .name = "commandTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for freqSweepTask */
osThreadId_t freqSweepTaskHandle;
const osThreadAttr_t freqSweepTask_attributes = {
  .name = "freqSweepTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for playTask */
osThreadId_t playTaskHandle;
const osThreadAttr_t playTask_attributes = {
  .name = "playTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for uartLock */
osMutexId_t uartLockHandle;
const osMutexAttr_t uartLock_attributes = {
  .name = "uartLock"
};
/* Definitions for freqRampSem */
osSemaphoreId_t freqRampSemHandle;
const osSemaphoreAttr_t freqRampSem_attributes = {
  .name = "freqRampSem"
};
/* Definitions for rampDoneSem */
osSemaphoreId_t rampDoneSemHandle;
const osSemaphoreAttr_t rampDoneSem_attributes = {
  .name = "rampDoneSem"
};
/* Definitions for playStartSem */
osSemaphoreId_t playStartSemHandle;
const osSemaphoreAttr_t playStartSem_attributes = {
  .name = "playStartSem"
};
/* USER CODE BEGIN PV */
#define TABLE_SIZE 64

// 64-point sine wave table used by the DAC DMA
uint16_t wavetable64[TABLE_SIZE];

// Current sine wave frequency and amplitude settings
volatile uint32_t toneHz = 1000;
volatile uint32_t gainPercent = 50;

// Ramp command settings
volatile uint32_t sweepStartHz = 100;
volatile uint32_t sweepStepHz = 100;
volatile uint32_t sweepStopHz = 1000;

// Row Row Row Your Boat - short clean version
uint32_t melodyNotes[] = {
  262, 262, 262, 294, 330,
  330, 294, 330, 349, 392,

  523, 523, 523,
  392, 392, 392,
  330, 330, 330,
  262, 262, 262,

  392, 349, 330, 294, 262
};

uint32_t melodyDurations[] = {
  250, 250, 200, 200, 400,
  200, 200, 200, 200, 600,

  150, 150, 250,
  150, 150, 250,
  150, 150, 250,
  150, 150, 250,

  250, 250, 250, 250, 700
};

uint32_t melodyLength = sizeof(melodyNotes) / sizeof(melodyNotes[0]);

// Imperial March (Darth Vader) - simplified version
uint32_t melody2Notes[] = {
  440, 440, 440, 349, 523,
  440, 349, 523, 440,

  659, 659, 659, 698, 523,
  415, 349, 523, 440,

  880, 440, 440, 880, 830,
  784, 740, 698, 740, 466,

  622, 587, 554, 523, 466,
  523, 349, 415, 440
};

uint32_t melody2Durations[] = {
  500, 500, 500, 350, 150,
  500, 350, 150, 1000,

  500, 500, 500, 350, 150,
  500, 350, 150, 1000,

  500, 300, 150, 500, 300,
  150, 150, 150, 300, 150,

  500, 300, 150, 150, 150,
  300, 300, 150, 1000
};

uint32_t melody2Length = sizeof(melody2Notes) / sizeof(melody2Notes[0]);

// Super Mario Theme intro for /playtest3
uint32_t melody3Notes[] = {
  659, 659, 0, 659,
  0, 523, 659, 0,
  784, 0, 0, 0,

  392, 0, 0, 0,

  523, 0, 0, 392,
  0, 0, 330, 0,

  0, 440, 0, 494,
  0, 466, 440, 0,

  392, 659, 784,
  880, 0, 698, 784,

  0, 659, 0, 523,
  587, 494, 0, 0
};

uint32_t melody3Durations[] = {
  150, 150, 80, 150,
  80, 150, 150, 80,
  300, 80, 80, 250,

  300, 80, 80, 250,

  150, 80, 150, 150,
  80, 150, 150, 80,

  150, 80, 150, 150,
  80, 150, 150, 250,

  150, 150, 150,
  250, 80, 150, 150,

  80, 150, 80, 150,
  150, 300, 80, 250
};

uint32_t melody3Length = sizeof(melody3Notes) / sizeof(melody3Notes[0]);

// Selects which playtest melody should run
// 1 = Row Row Row Your Boat
// 2 = magical/wizard-style melody
volatile uint8_t playMode = 1;

// Semaphore to trigger playtest task
osSemaphoreId_t playSemHandle;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_CRC_Init(void);
static void MX_DMA2D_Init(void);
static void MX_FMC_Init(void);
static void MX_LTDC_Init(void);
static void MX_SPI5_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM7_Init(void);
void StartCommandTask(void *argument);
void StartFreqSweepTask(void *argument);
void StartPlayTask(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void GenerateSineWave()
{
    for (int i = 0; i < TABLE_SIZE; i++)
    {
    	float angle = (2.0f * M_PI * i) / TABLE_SIZE;

    	float value = (sinf(angle) + 1.0f) * 2047.5f;

    	uint16_t sample = (uint16_t)value;

    	sample = (sample * gainPercent) / 100.0f;

    	wavetable64[i] = sample;
    }
}

void UpdateFrequency(uint32_t freq)
{
    if (freq < 20 || freq > 10000)
    {
        HAL_TIM_Base_Stop(&htim7);
        return;
    }

    toneHz = freq;

    uint32_t timerClock = HAL_RCC_GetPCLK1Freq();

    if ((RCC->CFGR & RCC_CFGR_PPRE1) != RCC_CFGR_PPRE1_DIV1)
    {
        timerClock *= 2;
    }

    uint32_t sampleRate = freq * TABLE_SIZE;
    uint32_t newARR = (timerClock / sampleRate) - 1;

    __HAL_TIM_SET_AUTORELOAD(&htim7, newARR);
    __HAL_TIM_SET_COUNTER(&htim7, 0);
}

void UpdateAmplitude(uint32_t amp)
{
    if (amp > 100)
        amp = 100;

    gainPercent = amp;

    GenerateSineWave();
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_CRC_Init();
  MX_DMA2D_Init();
  MX_FMC_Init();
  MX_LTDC_Init();
  MX_SPI5_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  MX_DAC_Init();
  MX_TIM7_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();
  /* Create the mutex(es) */
  /* creation of uartLock */
  uartLockHandle = osMutexNew(&uartLock_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of freqRampSem */
  freqRampSemHandle = osSemaphoreNew(1, 0, &freqRampSem_attributes);

  /* creation of rampDoneSem */
  rampDoneSemHandle = osSemaphoreNew(1, 0, &rampDoneSem_attributes);

  /* creation of playStartSem */
  playStartSemHandle = osSemaphoreNew(1, 0, &playStartSem_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of commandTask */
  commandTaskHandle = osThreadNew(StartCommandTask, NULL, &commandTask_attributes);

  /* creation of freqSweepTask */
  freqSweepTaskHandle = osThreadNew(StartFreqSweepTask, NULL, &freqSweepTask_attributes);

  /* creation of playTask */
  playTaskHandle = osThreadNew(StartPlayTask, NULL, &playTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 72;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_T7_TRGO;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief DMA2D Initialization Function
  * @param None
  * @retval None
  */
static void MX_DMA2D_Init(void)
{

  /* USER CODE BEGIN DMA2D_Init 0 */

  /* USER CODE END DMA2D_Init 0 */

  /* USER CODE BEGIN DMA2D_Init 1 */

  /* USER CODE END DMA2D_Init 1 */
  hdma2d.Instance = DMA2D;
  hdma2d.Init.Mode = DMA2D_M2M;
  hdma2d.Init.ColorMode = DMA2D_OUTPUT_ARGB8888;
  hdma2d.Init.OutputOffset = 0;
  hdma2d.LayerCfg[1].InputOffset = 0;
  hdma2d.LayerCfg[1].InputColorMode = DMA2D_INPUT_ARGB8888;
  hdma2d.LayerCfg[1].AlphaMode = DMA2D_NO_MODIF_ALPHA;
  hdma2d.LayerCfg[1].InputAlpha = 0;
  if (HAL_DMA2D_Init(&hdma2d) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DMA2D_ConfigLayer(&hdma2d, 1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DMA2D_Init 2 */

  /* USER CODE END DMA2D_Init 2 */

}

/**
  * @brief LTDC Initialization Function
  * @param None
  * @retval None
  */
static void MX_LTDC_Init(void)
{

  /* USER CODE BEGIN LTDC_Init 0 */

  /* USER CODE END LTDC_Init 0 */

  LTDC_LayerCfgTypeDef pLayerCfg = {0};
  LTDC_LayerCfgTypeDef pLayerCfg1 = {0};

  /* USER CODE BEGIN LTDC_Init 1 */

  /* USER CODE END LTDC_Init 1 */
  hltdc.Instance = LTDC;
  hltdc.Init.HSPolarity = LTDC_HSPOLARITY_AL;
  hltdc.Init.VSPolarity = LTDC_VSPOLARITY_AL;
  hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;
  hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;
  hltdc.Init.HorizontalSync = 7;
  hltdc.Init.VerticalSync = 3;
  hltdc.Init.AccumulatedHBP = 14;
  hltdc.Init.AccumulatedVBP = 5;
  hltdc.Init.AccumulatedActiveW = 654;
  hltdc.Init.AccumulatedActiveH = 485;
  hltdc.Init.TotalWidth = 660;
  hltdc.Init.TotalHeigh = 487;
  hltdc.Init.Backcolor.Blue = 0;
  hltdc.Init.Backcolor.Green = 0;
  hltdc.Init.Backcolor.Red = 0;
  if (HAL_LTDC_Init(&hltdc) != HAL_OK)
  {
    Error_Handler();
  }
  pLayerCfg.WindowX0 = 0;
  pLayerCfg.WindowX1 = 0;
  pLayerCfg.WindowY0 = 0;
  pLayerCfg.WindowY1 = 0;
  pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_ARGB8888;
  pLayerCfg.Alpha = 0;
  pLayerCfg.Alpha0 = 0;
  pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
  pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
  pLayerCfg.FBStartAdress = 0;
  pLayerCfg.ImageWidth = 0;
  pLayerCfg.ImageHeight = 0;
  pLayerCfg.Backcolor.Blue = 0;
  pLayerCfg.Backcolor.Green = 0;
  pLayerCfg.Backcolor.Red = 0;
  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg, 0) != HAL_OK)
  {
    Error_Handler();
  }
  pLayerCfg1.WindowX0 = 0;
  pLayerCfg1.WindowX1 = 0;
  pLayerCfg1.WindowY0 = 0;
  pLayerCfg1.WindowY1 = 0;
  pLayerCfg1.PixelFormat = LTDC_PIXEL_FORMAT_ARGB8888;
  pLayerCfg1.Alpha = 0;
  pLayerCfg1.Alpha0 = 0;
  pLayerCfg1.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
  pLayerCfg1.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
  pLayerCfg1.FBStartAdress = 0;
  pLayerCfg1.ImageWidth = 0;
  pLayerCfg1.ImageHeight = 0;
  pLayerCfg1.Backcolor.Blue = 0;
  pLayerCfg1.Backcolor.Green = 0;
  pLayerCfg1.Backcolor.Red = 0;
  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg1, 1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LTDC_Init 2 */

  /* USER CODE END LTDC_Init 2 */

}

/**
  * @brief SPI5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI5_Init(void)
{

  /* USER CODE BEGIN SPI5_Init 0 */

  /* USER CODE END SPI5_Init 0 */

  /* USER CODE BEGIN SPI5_Init 1 */

  /* USER CODE END SPI5_Init 1 */
  /* SPI5 parameter configuration*/
  hspi5.Instance = SPI5;
  hspi5.Init.Mode = SPI_MODE_MASTER;
  hspi5.Init.Direction = SPI_DIRECTION_2LINES;
  hspi5.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi5.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi5.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi5.Init.NSS = SPI_NSS_SOFT;
  hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi5.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi5.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI5_Init 2 */

  /* USER CODE END SPI5_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 0;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 1000;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);

}

/* FMC initialization function */
static void MX_FMC_Init(void)
{

  /* USER CODE BEGIN FMC_Init 0 */

  /* USER CODE END FMC_Init 0 */

  FMC_SDRAM_TimingTypeDef SdramTiming = {0};

  /* USER CODE BEGIN FMC_Init 1 */

  /* USER CODE END FMC_Init 1 */

  /** Perform the SDRAM1 memory initialization sequence
  */
  hsdram1.Instance = FMC_SDRAM_DEVICE;
  /* hsdram1.Init */
  hsdram1.Init.SDBank = FMC_SDRAM_BANK2;
  hsdram1.Init.ColumnBitsNumber = FMC_SDRAM_COLUMN_BITS_NUM_8;
  hsdram1.Init.RowBitsNumber = FMC_SDRAM_ROW_BITS_NUM_12;
  hsdram1.Init.MemoryDataWidth = FMC_SDRAM_MEM_BUS_WIDTH_16;
  hsdram1.Init.InternalBankNumber = FMC_SDRAM_INTERN_BANKS_NUM_4;
  hsdram1.Init.CASLatency = FMC_SDRAM_CAS_LATENCY_3;
  hsdram1.Init.WriteProtection = FMC_SDRAM_WRITE_PROTECTION_DISABLE;
  hsdram1.Init.SDClockPeriod = FMC_SDRAM_CLOCK_PERIOD_2;
  hsdram1.Init.ReadBurst = FMC_SDRAM_RBURST_DISABLE;
  hsdram1.Init.ReadPipeDelay = FMC_SDRAM_RPIPE_DELAY_1;
  /* SdramTiming */
  SdramTiming.LoadToActiveDelay = 2;
  SdramTiming.ExitSelfRefreshDelay = 7;
  SdramTiming.SelfRefreshTime = 4;
  SdramTiming.RowCycleDelay = 7;
  SdramTiming.WriteRecoveryTime = 3;
  SdramTiming.RPDelay = 2;
  SdramTiming.RCDDelay = 2;

  if (HAL_SDRAM_Init(&hsdram1, &SdramTiming) != HAL_OK)
  {
    Error_Handler( );
  }

  /* USER CODE BEGIN FMC_Init 2 */

  /* USER CODE END FMC_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, ACP_RST_Pin|AMP_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, RDX_Pin|WRX_DCX_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, LD3_Pin|LD4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : NCS_MEMS_SPI_Pin CSX_Pin OTG_FS_PSO_Pin */
  GPIO_InitStruct.Pin = NCS_MEMS_SPI_Pin|CSX_Pin|OTG_FS_PSO_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : B1_Pin MEMS_INT1_Pin MEMS_INT2_Pin TP_INT1_Pin */
  GPIO_InitStruct.Pin = B1_Pin|MEMS_INT1_Pin|MEMS_INT2_Pin|TP_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : ACP_RST_Pin AMP_EN_Pin */
  GPIO_InitStruct.Pin = ACP_RST_Pin|AMP_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : OTG_FS_OC_Pin */
  GPIO_InitStruct.Pin = OTG_FS_OC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(OTG_FS_OC_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : BOOT1_Pin */
  GPIO_InitStruct.Pin = BOOT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BOOT1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : TE_Pin */
  GPIO_InitStruct.Pin = TE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(TE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RDX_Pin WRX_DCX_Pin */
  GPIO_InitStruct.Pin = RDX_Pin|WRX_DCX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : I2C3_SDA_Pin */
  GPIO_InitStruct.Pin = I2C3_SDA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C3;
  HAL_GPIO_Init(I2C3_SDA_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD4_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartCommandTask */
/**
  * @brief  Function implementing the commandTask thread.
  * @param  argument: Not used
  * @retval None
  */
void StartCommandTask(void *argument)
{
  /* init code for USB_HOST */
  MX_USB_HOST_Init();

  GenerateSineWave();

  HAL_TIM_Base_Start(&htim7);

  HAL_DAC_Start_DMA(&hdac,
                    DAC_CHANNEL_2,
                    (uint32_t*)wavetable64,
                    TABLE_SIZE,
                    DAC_ALIGN_12B_R);

  HAL_TIM_Base_Stop(&htim7);

  /* USER CODE BEGIN 5 */
  char rx;
  char buffer[100];
  int idx = 0;

  playSemHandle = osSemaphoreNew(1, 0, NULL);
  osSemaphoreAcquire(playSemHandle, 0);

  char readyMsg[] = "\r\nCLI Ready. Type /help\r\n";
  HAL_UART_Transmit(&huart1, (uint8_t*)readyMsg, strlen(readyMsg), 100);

  for(;;)
  {
    if (HAL_UART_Receive(&huart1, (uint8_t*)&rx, 1, HAL_MAX_DELAY) == HAL_OK)
    {
      if (rx == '\b' || rx == 127)
      {
        if (idx > 0)
        {
          idx--;
          HAL_UART_Transmit(&huart1, (uint8_t*)"\b \b", 3, 100);
        }
      }
      else if (rx == '\r' || rx == '\n')
      {
        HAL_UART_Transmit(&huart1, (uint8_t*)"\r\n", 2, 100);

        buffer[idx] = '\0';

        if (idx == 0)
        {
          continue;
        }

        // remove trailing CR/LF if any slipped in
        while (idx > 0 && (buffer[idx - 1] == '\r' || buffer[idx - 1] == '\n'))
        {
          buffer[idx - 1] = '\0';
          idx--;
        }

        if (strcmp(buffer, "/help") == 0)
        {
          char helpMsg[] =
            "Commands:\r\n"
            "/help\r\n"
            "/about\r\n"
            "/clear\r\n"
            "/sine set freq <20-10000>\r\n"
            "/sine set amp <0-100>\r\n"
            "/sine ramp <start>,<step>,<stop>\r\n"
            "/playtest<1,2,3>\r\n";
          HAL_UART_Transmit(&huart1, (uint8_t*)helpMsg, strlen(helpMsg), 300);
        }
        else if (strcmp(buffer, "/about") == 0)
        {
          char aboutMsg[] =
            "Project 5 Audio CLI\r\n"
            "Amna Malik - R11827604\r\n"
            "STM32F429 + BOOST-XL Audio\r\n"
            "DAC + DMA sine wave control\r\n"
            "Build: " __DATE__ " " __TIME__ "\r\n";
          HAL_UART_Transmit(&huart1, (uint8_t*)aboutMsg, strlen(aboutMsg), 300);
        }
        else if (strcmp(buffer, "/clear") == 0)
        {
          char clearMsg[] = "\033[2J\033[H";
          HAL_UART_Transmit(&huart1, (uint8_t*)clearMsg, strlen(clearMsg), 100);
        }
        else if (strncmp(buffer, "/sine set freq ", 15) == 0)
        {
          uint32_t f = atoi(&buffer[15]);
          UpdateFrequency(f);
          HAL_TIM_Base_Start(&htim7);
        }
        else if (strncmp(buffer, "/sine set amp ", 14) == 0)
        {
          uint32_t a = atoi(&buffer[14]);
          UpdateAmplitude(a);
        }
        else if (strncmp(buffer, "/sine ramp ", 11) == 0)
        {
          sscanf(&buffer[11], "%lu,%lu,%lu",
                 &sweepStartHz,
                 &sweepStepHz,
                 &sweepStopHz);

          if (sweepStartHz >= 20 && sweepStopHz <= 10000 && sweepStepHz > 0)
          {
            osSemaphoreRelease(freqRampSemHandle);
          }
          else
          {
            HAL_TIM_Base_Stop(&htim7);
            char badRampMsg[] = "Invalid ramp. Use: /sine ramp <20-10000>,<step>,<20-10000>\r\n";
            HAL_UART_Transmit(&huart1, (uint8_t*)badRampMsg, strlen(badRampMsg), 300);
          }
        }
        else if (strcmp(buffer, "/playtest") == 0)
        {
          playMode = 1;
          osSemaphoreRelease(playSemHandle);
        }
        else if (strcmp(buffer, "/playtest2") == 0)
        {
          playMode = 2;
          osSemaphoreRelease(playSemHandle);
        }
        else if (strcmp(buffer, "/playtest3") == 0)
        {
          playMode = 3;
          osSemaphoreRelease(playSemHandle);
        }
        else
        {
          char invalidMsg[] = "Invalid command. Type /help\r\n";
          HAL_UART_Transmit(&huart1, (uint8_t*)invalidMsg, strlen(invalidMsg), 200);
        }

        idx = 0;
      }
      else
      {
        if (idx < sizeof(buffer) - 1)
        {
          buffer[idx++] = rx;
          HAL_UART_Transmit(&huart1, (uint8_t*)&rx, 1, 100);
        }
      }
    }
  }
  /* USER CODE END 5 */
  }

/* USER CODE BEGIN Header_StartFreqSweepTask */
/**
* @brief Function implementing the freqSweepTask thread.
* @param argument: Not used
* @retval None
*/
void StartFreqSweepTask(void *argument)
{
  /* USER CODE BEGIN StartFreqSweepTask */
  for(;;)
  {
    osSemaphoreAcquire(freqRampSemHandle, osWaitForever);

    HAL_TIM_Base_Start(&htim7);
    osDelay(20);

    for (uint32_t f = sweepStartHz; f <= sweepStopHz; f += sweepStepHz)
    {
      UpdateFrequency(f);
      HAL_TIM_Base_Start(&htim7);

      // play one full wave at this frequency
      uint32_t delayMs = 1000 / f;

      if (delayMs == 0)
      {
        delayMs = 1;
      }

      osDelay(delayMs);
    }

    HAL_TIM_Base_Stop(&htim7);

    // notify ramp finished
    osSemaphoreRelease(rampDoneSemHandle);
  }
  /* USER CODE END StartFreqSweepTask */
}

/* USER CODE BEGIN Header_StartPlayTask */
/**
* @brief Function implementing the playTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartPlayTask */
void StartPlayTask(void *argument)
{
  /* USER CODE BEGIN StartPlayTask */
  for(;;)
  {
    while (playSemHandle == NULL)
    {
      osDelay(10);
    }

    if (osSemaphoreAcquire(playSemHandle, osWaitForever) == osOK)
    {
      char playMsg[] = "playing\r\n";
      HAL_UART_Transmit(&huart1, (uint8_t*)playMsg, strlen(playMsg), 100);

      uint32_t *notes;
      uint32_t *durations;
      uint32_t length;

      if (playMode == 3)
      {
        notes = melody3Notes;
        durations = melody3Durations;
        length = melody3Length;
      }
      else if (playMode == 2)
      {
        notes = melody2Notes;
        durations = melody2Durations;
        length = melody2Length;
      }
      else
      {
        notes = melodyNotes;
        durations = melodyDurations;
        length = melodyLength;
      }

      for (uint32_t i = 0; i < length; i++)
      {
        if (notes[i] == 0)
        {
          HAL_TIM_Base_Stop(&htim7);
          osDelay(durations[i] / 2);   // shorter pause
        }
        else
        {
          UpdateFrequency(notes[i]);
          HAL_TIM_Base_Start(&htim7);
          osDelay(durations[i]);
        }
      }

      HAL_TIM_Base_Stop(&htim7);

      char doneMsg[] = "done\r\n";
      HAL_UART_Transmit(&huart1, (uint8_t*)doneMsg, strlen(doneMsg), 100);
    }
  }
  /* USER CODE END StartPlayTask */
}
/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
