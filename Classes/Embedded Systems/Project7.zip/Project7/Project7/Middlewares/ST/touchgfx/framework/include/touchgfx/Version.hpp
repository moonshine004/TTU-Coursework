/******************************************************************************
* Copyright (c) 2018(-2026) STMicroelectronics.
* All rights reserved.
*
* This file is part of the TouchGFX 4.26.1 distribution.
*
* This software is licensed under terms that can be found in the LICENSE file in
* the root directory of this software component.
* If no LICENSE file comes with this software, it is provided AS-IS.
*
*******************************************************************************/

#ifndef TOUCHGFX_VERSION_HPP
#define TOUCHGFX_VERSION_HPP

#define TOUCHGFX_VERSION 42601
#define TOUCHGFX_VERSION_MAJOR 4
#define TOUCHGFX_VERSION_MINOR 26
#define TOUCHGFX_VERSION_PATCH 1

#endif // TOUCHGFX_VERSION_HPP
